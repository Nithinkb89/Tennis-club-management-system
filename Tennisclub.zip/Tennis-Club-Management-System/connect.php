<?php 
$link=mysqli_connect("localhost","root","","tms")or die("Can't Connect...");
	
?>